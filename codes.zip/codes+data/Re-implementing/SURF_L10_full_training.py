# -*- coding: utf-8 -*-


import os
import scipy.io
import numpy as np
from scipy.linalg import fractional_matrix_power
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC

os.chdir("/Users/tjmask/Desktop/Semester2/DataMining/Final Project/Re-implementing")

def full_training_coral(source, target):
    data = scipy.io.loadmat('SURF_L10.mat')
    source_lbl = source+'_lbl'
    target_lbl = target+'_lbl'
    Ds = data[source]
    source_label = data[source_lbl]
    Dt = data[target]
    target_label = data[target_lbl]
    
    #Coral transform
    Cs = np.cov(Ds.T)+np.diag(np.ones(Ds.shape[1]))
    Ct = np.cov(Dt.T)+np.diag(np.ones(Dt.shape[1]))
    Ds = np.dot(Ds,fractional_matrix_power(Cs, -0.5).real)
    Ds_ = np.dot(Ds,fractional_matrix_power(Ct, 0.5).real)
    # print(Cs, Ds_,'111111111111111111111')
    train_x = Ds_
    train_y = np.ravel(source_label)
    test_x = Dt
    test_y = np.ravel(target_label)
    # print(test_y, '111111111111111111111')
    #get prediction
    C_range = list(np.logspace(-2, 10, 5))
    gamma_range = list(np.logspace(-9, 3, 5))
    Accuracy_list=[]
    for c in C_range:
        print(c,'222222222222222222')
        for g in gamma_range:
            print(g,'3333333333333333333')
            RBF_SVM = SVC(C=c, gamma=g)
            RBF_SVM.fit(train_x,train_y)
            pred = RBF_SVM.predict(test_x)
            Accuracy_list.append(accuracy_score(test_y, pred))
    Max_accuracy=max(Accuracy_list)
    print(Max_accuracy)
    # return Max_accuracy
    
full_training_coral('amazon', 'caltech')
# full_training_coral('amazon', 'dslr')
# full_training_coral('amazon', 'webcam')

# full_training_coral('caltech', 'amazon')
# full_training_coral('caltech', 'dslr')
# full_training_coral('caltech', 'webcam')

# full_training_coral('dslr', 'amazon')
# full_training_coral('dslr', 'caltech')
# full_training_coral('dslr', 'webcam')

# full_training_coral('webcam', 'amazon')
# full_training_coral('webcam', 'caltech')
# full_training_coral('webcam', 'dslr')